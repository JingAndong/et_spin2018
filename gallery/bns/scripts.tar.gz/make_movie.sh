#!/bin/bash

visit -cli -nowin -s rho.movie.py
